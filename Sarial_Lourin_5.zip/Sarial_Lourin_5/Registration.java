import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
public class Registration{
    
     public static void main(String[] args){
        JFrame frame = new JFrame("Campus Event Registration System");
        frame.setSize(750, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout(FlowLayout.LEFT,20,1));

        JLabel lblName = new JLabel("Participant Name: ");
        JTextField txtName = new JTextField(15);
       
        JLabel lblAge = new JLabel("Age: ");
        JTextField txtAge = new JTextField(10);

        JLabel lblDepartment = new JLabel("College/Department:");
        String[] Department = {"Select your Department", "BSIT", "BFPT", "BTLED"};
        JComboBox<String> cmbDepartment = new JComboBox<>(Department);

        JLabel lblEvent = new JLabel("Event Category:");
        String[] Event = {"Select Event", "Programming Competition", "Web Design Challenge", "Cybersecurity Seminar", "AI and Emerging Technologies", "IT Quiz Bowl"};
        JComboBox<String> cmbEvent = new JComboBox<>(Event);

        JLabel lblAttendance = new JLabel("Select Attendance Type: ");
        JRadioButton f = new JRadioButton("Student Participant");
        JRadioButton g = new JRadioButton("Student Audience");
        JRadioButton h = new JRadioButton("Faculty/Staff ");
        
        ButtonGroup Attendance = new ButtonGroup();
        Attendance.add(f);
        Attendance.add(g);
        Attendance.add(h);

        JLabel lblWorkShops = new JLabel("Workshops to Attend: ");
        JCheckBox WorkShops1 = new JCheckBox("Java Programming");
        JCheckBox WorkShops2 = new JCheckBox("Web Development");
        JCheckBox WorkShops3 = new JCheckBox("Cybersecurity");
        JCheckBox WorkShops4 = new JCheckBox("Artificial Intelligence");
        JCheckBox WorkShops5 = new JCheckBox("Database Management");

        JLabel lblRequest = new JLabel("Special Request: ");
        JTextArea txtRequest = new JTextArea(2, 10);

        txtRequest.setLineWrap(true);
        txtRequest.setWrapStyleWord(true);

        JButton btnRegister = new JButton("Register");
        JButton btnClear = new JButton("Clear");
        


        frame.add(lblName);
        frame.add(txtName);
        frame.add(lblAge);
        frame.add(txtAge);
        frame.add(lblDepartment);
        frame.add(cmbDepartment);
        frame.add(lblEvent);
        frame.add(cmbEvent);
        frame.add(lblAttendance);
        frame.add(f);
        frame.add(g);
        frame.add(h);
        frame.add(lblWorkShops);
        frame.add(WorkShops1);
        frame.add(WorkShops2);
        frame.add(WorkShops3);
        frame.add(WorkShops4);
        frame.add(WorkShops5);
        frame.add(lblRequest);
        frame.add(txtRequest);
        frame.add(btnRegister);
        frame.add(btnClear);




        btnRegister.addActionListener(e ->{
            String name = txtName.getText().trim();
            String age = txtAge.getText().trim();
            String department = cmbDepartment.getSelectedItem().toString();
            String event = cmbEvent.toString();


            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Participant Name is required!");
                return;
            }

            if (age.isEmpty()) {
                JOptionPane.showMessageDialog(frame,"Age is required!");
                return;
            }

              int ageValue;

            try {
                ageValue = Integer.parseInt(age);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame,"Age must be a valid whole number.");
                return;
            }

            if (ageValue <= 0) {
                JOptionPane.showMessageDialog(frame, "Age must be greater than zero." );
                return;
            }

            if (department.isEmpty()) {
                JOptionPane.showMessageDialog(frame,"College/Department is required!");
                return;
            }

            if (cmbEvent.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(frame,"Please select an Event Category!");
                return;
            }
             
             String attendanceType = "";

            if (f.isSelected()) {attendanceType = "Student Participant";}
            
            else if
                (g.isSelected()) {attendanceType = "Student Audience";}
            
            else if
                (h.isSelected()) {attendanceType = "Faculty/Staff";}
            
            else {
                JOptionPane.showMessageDialog(frame,"Attendance Type Required!" );
                return;
            }

            String workshops = "";

            if (WorkShops1.isSelected()) {
                workshops += "Java Programming, ";
            }

            if (WorkShops2.isSelected()) {
                workshops += "Web Development, ";
            }

            if (WorkShops3.isSelected()) {
                workshops += "Cybersecurity, ";
            }

            if (WorkShops4.isSelected()) {
                workshops += "Artificial Intelligence, ";
            }

            if (WorkShops5.isSelected()) {
                workshops += "Database Management, ";
            }

            if (workshops.isEmpty()) {
                workshops = "None";
            }
            else {
                workshops = workshops.substring(0,workshops.length() - 2);
            }

            String notes = txtRequest.getText().trim();

            if (notes.isEmpty()) {
                notes = "None";
            }

             String message = "-----REGISTRATION SUMMARY-----\n\n" + "Participant Name: " + name + "\nAge: " + age + "\nCollege/Department: " + department + "\nEvent Category: " + cmbEvent.getSelectedItem() + "\nAttendance Type: " + attendanceType + "\nWorkshops: " + workshops + "\nSpecial Request/Notes: " + notes;

            JOptionPane.showMessageDialog(frame, message,"Registration Successful",JOptionPane.INFORMATION_MESSAGE);
        });

        btnClear.addActionListener(e -> {

            txtName.setText("");
            txtAge.setText("");
            cmbDepartment.setSelectedIndex(0);
            cmbEvent.setSelectedIndex(0);

            Attendance.clearSelection();

            WorkShops1.setSelected(false);
            WorkShops2.setSelected(false);
            WorkShops3.setSelected(false);
            WorkShops4.setSelected(false);
            WorkShops5.setSelected(false);

            txtRequest.setText("");
      });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

}
}